console.log("Starting server.js...");
