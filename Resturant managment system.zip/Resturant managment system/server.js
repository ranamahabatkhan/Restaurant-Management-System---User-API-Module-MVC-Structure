console.log("Starting server.js...");
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
//const connectDB = require('./config/db');

// Route files
//onst userRoutes = require('./routes/userRoutes');

// Connect to database
//connectDB();

// Initialize app
const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Mount routers
//app.use('/api/users', userRoutes);

// Welcome route
app.get('/', (req, res) => {
  res.send(`
    <h1>Restaurant Management System API</h1>
    <p>User Module Endpoints:</p>
    <ul>
      <li>POST /api/users/register/new - Register new user</li>
      <li>POST /api/users/login - User login</li>
      <li>GET /api/users/list - Get all users (admin only)</li>
      <li>PUT /api/users/:id/role - Update user role (admin only)</li>
      <li>PUT /api/users/:id/password - Update user password</li>
      <li>DELETE /api/users/:id - Delete user (admin only)</li>
    </ul>
    <p>Note: For admin routes, include header: x-admin: true</p>
  `);
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Server error'
  });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
  