const express = require('express');
const userController = require('../controllers/userController');

const router = express.Router();

// Public routes
router.post('/register/new', userController.registerUser);
router.post('/login', userController.loginUser);

// Protected routes (using simple header check for now)
router.put('/:id/role', userController.updateUserRole);
router.get('/list', userController.getAllUsers);
router.put('/:id/password', userController.updateUserPassword);
router.delete('/:id', userController.deleteUser);

module.exports = router;